/*
 * MyRobot.h
 *
 *  Created on: May 2, 2014
 *      Author: pim
 */

#ifndef MYROBOT_H_
#define MYROBOT_H_
#include "CGFobject.h"
class MyRobot : public CGFobject {
public:
	MyRobot();
	void draw();
	virtual ~MyRobot();
};

#endif /* MYROBOT_H_ */
