/*
 * MyRobot.cpp
 *
 *  Created on: May 2, 2014
 *      Author: pim
 */

#include "MyRobot.h"

MyRobot::MyRobot() {
	// TODO Auto-generated constructor stub

}

MyRobot::~MyRobot() {
	// TODO Auto-generated destructor stub
}

void MyRobot::draw(){

	glNormal3d(0,1,0);
	glBegin(GL_TRIANGLES);
	glVertex3d(-0.5, 0,0.5);
	glVertex3d(0.5, 0,0.5);
	glVertex3d(0, 0,-0.5);


	glEnd();

}
