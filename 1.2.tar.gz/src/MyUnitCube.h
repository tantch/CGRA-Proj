/*
 * MyUnitCube.h
 *
 *  Created on: Feb 25, 2014
 *      Author: pim
 */

#ifndef MYUNITCUBE_H_
#define MYUNITCUBE_H_
#include "CGFobject.h"
class myUnitCube: public CGFobject {
	public:
		void draw();
};



#endif /* MYUNITCUBE_H_ */
