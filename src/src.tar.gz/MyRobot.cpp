/*
 * MyRobot.cpp
 *
 *  Created on: May 2, 2014
 *      Author: pim
 */

#include "MyRobot.h"
#include <math.h>
#include <cmath>
#include <iostream>

using namespace std;
#define PI 3.14159265
MyRobot::MyRobot(int st) {
	float amb[3] = { 0.8, 0.8, 0.8 };
	float dif[3] = { 0.8, 0.8, 0.8 };
	float spec[3] = { 0.5, 0.5, 0.5 };
	float shininess = 120.f;

	appearance1 = new CGFappearance(amb, dif, spec, shininess);
	appearance1->setTexture("pyramid.jpg");
	appearance1->setTextureWrap(GL_CLAMP, GL_CLAMP);
	cx = 7;
	cy = 4;
	cz = 7;
	rty = 90;
	stacks = st;
	slices = 12;

	calculateDrawPoints();

}

MyRobot::~MyRobot() {
	// TODO Auto-generated destructor stub
}
void MyRobot::addNormal(vector<Ponto> pnts) {
	Ponto normal(0, 0, 0);
	for (unsigned int i = 0; i < pnts.size(); ++i) {
		Ponto A = pnts[i];
		Ponto B = pnts[(i + 1) % pnts.size()];

		normal.x = normal.x + ((A.y - B.y) * (A.z + B.z));
		normal.y = normal.y + ((A.z - B.z) * (A.x + B.x));
		normal.z = normal.z + ((A.x - B.x) * (A.y + B.y));
	}

	double tamanho = normal.getTamanho();
	normal.x = normal.x / tamanho;
	normal.y = normal.y / tamanho;
	normal.z = normal.z / tamanho;
	glNormal3d(normal.x, normal.y, normal.z);

}
void MyRobot::setPosition(float x, float y, float z) {
	if (x > 0)
		cx = x;
	if (y > 0)
		cy = y;
	if (z > 0)
		cz = z;

}
void MyRobot::setRotation(int rt) {
	rty = rt;
}

void MyRobot::calculateDrawPoints() {
	double alpha = -5 * PI / 4, dalpha = -PI / 6;
	double dx = 1 / 3;

	double xin, yin, delx, dely, kx, ky;

	for (int i = 0; i < 3; i++) {
		fc.push_back(vector<Ponto>());
		double x1 = cos((alpha + dalpha * (i))) * 0.25;
		double z1 = sin((alpha + dalpha * (i))) * 0.25;
		double x2 = cos((alpha + dalpha * (i + 1))) * 0.25;
		double z2 = sin((alpha + dalpha * (i + 1))) * 0.25;
		double px1 = -0.5 + (1 / 3.0) * i;
		double px2 = -0.5 + (1 / 3.0) * (i + 1);
		double pz1 = 0.5, pz2 = 0.5;
		double py = 0;
		double dkx;
		double dex1 = abs((x1 - px1) / stacks), dey = abs((1 - py) / stacks),
				dez1 = abs((z1 - pz1) / stacks);
		double dex2 = abs((x2 - px2) / stacks), dez2 = abs((z2 - pz2) / stacks);

		//base
		fc[i].push_back(Ponto(px1, py, pz1));
		fc[i].push_back(Ponto(px2, py, pz2));

		for (int k = 1; k < stacks; k++) {

			if (px1 < 0)
				px1 = px1 + dex1;
			else
				px1 = px1 - dex1;
			if (px2 < 0)
				px2 = px2 + dex2;
			else
				px2 = px2 - dex2;
			py = py + dey;
			pz1 = pz1 - dez1;
			pz2 = pz2 - dez2;

			//meio
			fc[i].push_back(Ponto(px1, py, pz1));
			fc[i].push_back(Ponto(px2, py, pz2));

		}

		fc[i].push_back(Ponto(x1, 1, z1));
		fc[i].push_back(Ponto(x2, 1, z2));

	}

}
void MyRobot::draw() {

	glPushMatrix();

	glTranslated(cx, cy, cz);
	glRotated(rty, 0, 1, 0);
	for (int k = 0; k < 4; k++) {
		glRotated(90, 0, 1, 0);

		for (int i = 0; i < 3; i++) {
			glBegin(GL_TRIANGLE_STRIP);

			for (int j = 0; j < fc[i].size(); j++) {
				vector<Ponto> pl;
				if (i == 0) {
					pl.push_back(fc[0][j]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[0][j + 2]);
					pl.push_back(fc[0][j + 1]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[0][j + 3]);
					pl.push_back(fc[1][j]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[1][j + 2]);
					pl.push_back(fc[1][j + 1]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[1][j + 3]);
				}
				else if (i == 1) {
					pl.push_back(fc[1][j]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[1][j + 2]);
					pl.push_back(fc[1][j + 1]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[1][j + 3]);
					pl.push_back(fc[2][j]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[2][j + 2]);
					pl.push_back(fc[2][j + 1]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[2][j + 3]);
				}
				else if (i == 2) {
					pl.push_back(fc[1][j]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[1][j + 2]);
					pl.push_back(fc[1][j + 1]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[1][j + 3]);
					pl.push_back(fc[2][j]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[2][j + 2]);
					pl.push_back(fc[2][j + 1]);
					if(j<fc[i].size()-2)
					pl.push_back(fc[2][j + 3]);
				}
				addNormal(fc[i]);
				glVertex3d(fc[i][j].x, fc[i][j].y, fc[i][j].z);

			}
			glVertex3d(0, 1, 0);
			glEnd();
		}

	}
	glPopMatrix();
}

