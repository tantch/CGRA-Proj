#pragma once

#include "MyUnitCube.h"

class myTable
{
private:
	myUnitCube cube;
public:
	myTable(void);
	~myTable(void);

	void draw();
};

