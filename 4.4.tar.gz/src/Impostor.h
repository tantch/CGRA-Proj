#pragma once

#include "CGFobject.h"

class Impostor
{
public:
	Impostor(void);
	~Impostor(void);
	void draw();
};

